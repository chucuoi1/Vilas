rclone move /mnt/UP1/ sa1:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP1/ sa10:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP1/ sa100:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP1/ sa11:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP1/ sa12:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP1/ sa13:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP1/ sa14:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP1/ sa15:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP1/ sa16:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP1/ sa17:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP1/ sa18:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP1/ sa19:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G

# rclone move /mnt/UP1/ sa2:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP1/ sa20:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP1/ sa21:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP1/ sa22:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP1/ sa23:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP1/ sa24:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP1/ sa25:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP1/ sa26:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP1/ sa27:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP1/ sa28:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP1/ sa29:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP1/ sa3:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G

