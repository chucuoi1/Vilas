rclone move /mnt/UP2/ sa30:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP2/ sa31:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP2/ sa32:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP2/ sa33:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP2/ sa34:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP2/ sa35:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP2/ sa36:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP2/ sa37:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP2/ sa38:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP2/ sa39:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP2/ sa4:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
rclone move /mnt/UP2/ sa40:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G

# rclone move /mnt/UP2/ sa41:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa42:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa43:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa44:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa45:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa46:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa47:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa48:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa49:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa5:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa50:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa51:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa52:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa53:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa54:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa55:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa56:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa57:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa58:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa59:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa6:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa60:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa61:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa62:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa63:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa64:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa65:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa66:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa67:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa68:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa69:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa7:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa70:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa71:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa72:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa73:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa74:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa75:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa76:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa77:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa78:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa79:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa8:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa80:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa81:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa82:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa83:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa84:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa85:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa86:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa87:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa88:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa89:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa9:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa90:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa91:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa92:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa93:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa94:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa95:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa96:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa97:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa98:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
# rclone move /mnt/UP2/ sa99:d28 --drive-stop-on-upload-limit --drive-chunk-size 1G
