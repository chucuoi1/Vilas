#!/bin/bash
sudo mount -t tmpfs -o rw,size=260G tmpfs /mnt/ramdisk1
sudo mount -t tmpfs -o rw,size=260G tmpfs /mnt/ramdisk2
rm -r /mnt/ramdisk1/
rm -r /mnt/ramdisk2/
sleep 3
bash /root/bash.sh
sleep 3
bash /root/plot1.sh
sleep 3
bash /root/plot2.sh
