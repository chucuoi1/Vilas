valid=true
while [ $valid ]
do
SOURCE=/root/Test/Source
DES=/root/Test/Dest
if compgen -G "/mnt/Final/*.plot" > /dev/null; then
  echo "Final has plot"
  if compgen -G "/mnt/UP2/*.plot" > /dev/null; then
  else
    echo "UP2 no plot"
    sleep 3s
    mv `ls /mnt/Final/*.plot | head -2` /mnt/UP2/
    echo "Moving"
	sleep 3s
	bash /root/rcloneDriveCommand2.sh
  fi
else sleep 2m
fi
done