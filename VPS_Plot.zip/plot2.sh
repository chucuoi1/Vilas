#!/bin/bash
cd ~/
screen -dmS Plot2 ./chia-plotter/build/chia_plot -w -t /mnt/ramdisk2/ -d /mnt/Final/ -2 /mnt/ramdisk2/ -n -1 -r 90 -f 8c9db573edff069681e522055e35ded4f289f556de80dd8b96d2b6e403757faf6edb819b32c8ac9601df03c691ec4659 -c xch16ndcj6hew6a69tcn6h7dtrj744gd60mzp78hl70lr2047lnrnzdq7z8s5c
