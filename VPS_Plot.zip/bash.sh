
pkill -f "up1.sh"

pkill -f "up2.sh"

pkill -f "move1.sh"

pkill -f "move2.sh"

nohup bash /root/move1.sh &

nohup bash /root/move2.sh &

nohup bash /root/up1.sh &

nohup bash /root/up2.sh &
